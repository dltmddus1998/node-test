/**
 * @internal
 */
export declare const SENSITIVE_STRING = "***SensitiveInformation***";
