/**
 * @internal
 */
export declare const resolvedPath: (resolvedPath: string, input: unknown, memberName: string, labelValueProvider: () => string | undefined, uriLabel: string, isGreedyLabel: boolean) => string;
