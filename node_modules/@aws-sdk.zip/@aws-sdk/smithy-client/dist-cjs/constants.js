"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SENSITIVE_STRING = void 0;
exports.SENSITIVE_STRING = "***SensitiveInformation***";
