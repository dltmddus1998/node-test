# @aws-sdk/util-base64

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/util-base64/latest.svg)](https://www.npmjs.com/package/@aws-sdk/util-base64)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/util-base64.svg)](https://www.npmjs.com/package/@aws-sdk/util-base64)
