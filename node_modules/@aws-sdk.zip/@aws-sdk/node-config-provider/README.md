# @aws-sdk/node-config-provider

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/node-config-provider/latest.svg)](https://www.npmjs.com/package/@aws-sdk/node-config-provider)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/node-config-provider.svg)](https://www.npmjs.com/package/@aws-sdk/node-config-provider)
