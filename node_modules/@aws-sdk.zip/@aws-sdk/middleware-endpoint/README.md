# @aws-sdk/middleware-endpoint

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/middleware-endpoint/latest.svg)](https://www.npmjs.com/package/@aws-sdk/middleware-endpoint)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/middleware-endpoint.svg)](https://www.npmjs.com/package/@aws-sdk/middleware-endpoint)

> An internal package

## Usage

You probably shouldn't, at least directly.
