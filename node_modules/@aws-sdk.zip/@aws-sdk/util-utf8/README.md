# @aws-sdk/util-utf8

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/util-utf8/latest.svg)](https://www.npmjs.com/package/@aws-sdk/util-utf8)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/util-utf8.svg)](https://www.npmjs.com/package/@aws-sdk/util-utf8)
