# @aws-sdk/util-waiter

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/util-waiter/latest.svg)](https://www.npmjs.com/package/@aws-sdk/util-waiter)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/util-waiter.svg)](https://www.npmjs.com/package/@aws-sdk/util-waiter)

> An internal package

## Usage

You probably shouldn't, at least directly.
