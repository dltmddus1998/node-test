"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.REFRESH_MESSAGE = exports.EXPIRE_WINDOW_MS = void 0;
exports.EXPIRE_WINDOW_MS = 5 * 60 * 1000;
exports.REFRESH_MESSAGE = `To refresh this SSO session run 'aws sso login' with the corresponding profile.`;
