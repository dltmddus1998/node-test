export const EXPIRE_WINDOW_MS = 5 * 60 * 1000;
export const REFRESH_MESSAGE = `To refresh this SSO session run 'aws sso login' with the corresponding profile.`;
