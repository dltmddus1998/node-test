# @aws-sdk/util-config-provider

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/util-config-provider/latest.svg)](https://www.npmjs.com/package/@aws-sdk/util-config-provider)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/util-config-provider.svg)](https://www.npmjs.com/package/@aws-sdk/util-config-provider)
