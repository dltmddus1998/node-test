import { HttpRequest } from "@aws-sdk/types";
/**
 * @private
 */
export declare const prepareRequest: (request: HttpRequest) => HttpRequest;
