import { HttpRequest } from "@aws-sdk/types";
/**
 * @private
 */
export declare const getCanonicalQuery: ({ query }: HttpRequest) => string;
