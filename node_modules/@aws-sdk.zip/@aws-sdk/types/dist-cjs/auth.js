"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpAuthLocation = void 0;
var HttpAuthLocation;
(function (HttpAuthLocation) {
    HttpAuthLocation["HEADER"] = "header";
    HttpAuthLocation["QUERY"] = "query";
})(HttpAuthLocation = exports.HttpAuthLocation || (exports.HttpAuthLocation = {}));
