"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EndpointURLScheme = void 0;
var EndpointURLScheme;
(function (EndpointURLScheme) {
    EndpointURLScheme["HTTP"] = "http";
    EndpointURLScheme["HTTPS"] = "https";
})(EndpointURLScheme = exports.EndpointURLScheme || (exports.EndpointURLScheme = {}));
