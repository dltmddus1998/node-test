"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HostAddressType = void 0;
var HostAddressType;
(function (HostAddressType) {
    HostAddressType["AAAA"] = "AAAA";
    HostAddressType["A"] = "A";
})(HostAddressType = exports.HostAddressType || (exports.HostAddressType = {}));
