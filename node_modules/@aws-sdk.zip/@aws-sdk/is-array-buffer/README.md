# @aws-sdk/is-array-buffer

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/is-array-buffer/latest.svg)](https://www.npmjs.com/package/@aws-sdk/is-array-buffer)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/is-array-buffer.svg)](https://www.npmjs.com/package/@aws-sdk/is-array-buffer)

> An internal package

## Usage

You probably shouldn't, at least directly.
