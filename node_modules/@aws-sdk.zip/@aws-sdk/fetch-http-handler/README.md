# @aws-sdk/fetch-http-handler

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/fetch-http-handler/latest.svg)](https://www.npmjs.com/package/@aws-sdk/fetch-http-handler)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/fetch-http-handler.svg)](https://www.npmjs.com/package/@aws-sdk/fetch-http-handler)
