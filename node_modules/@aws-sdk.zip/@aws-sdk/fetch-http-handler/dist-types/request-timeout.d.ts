export declare function requestTimeout(timeoutInMs?: number): Promise<never>;
