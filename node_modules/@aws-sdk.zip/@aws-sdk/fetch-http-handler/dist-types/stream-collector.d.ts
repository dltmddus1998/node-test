import { StreamCollector } from "@aws-sdk/types";
export declare const streamCollector: StreamCollector;
