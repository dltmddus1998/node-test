# @aws-sdk/util-middleware

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/util-middleware/latest.svg)](https://www.npmjs.com/package/@aws-sdk/util-middleware)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/util-middleware.svg)](https://www.npmjs.com/package/@aws-sdk/util-middleware)

> An internal package

This package provides shared utilities for middleware.

## Usage

You probably shouldn't, at least directly.
