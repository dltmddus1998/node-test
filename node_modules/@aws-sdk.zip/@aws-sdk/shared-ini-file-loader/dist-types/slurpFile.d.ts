interface SlurpFileOptions {
    ignoreCache?: boolean;
}
export declare const slurpFile: (path: string, options?: SlurpFileOptions) => Promise<string>;
export {};
