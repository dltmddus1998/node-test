export declare const ENV_PROFILE = "AWS_PROFILE";
export declare const DEFAULT_PROFILE = "default";
export declare const getProfileName: (init: {
    profile?: string;
}) => string;
