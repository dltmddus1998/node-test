/**
 * Returns the filepath of the file where SSO token is stored.
 */
export declare const getSSOTokenFilepath: (id: string) => string;
