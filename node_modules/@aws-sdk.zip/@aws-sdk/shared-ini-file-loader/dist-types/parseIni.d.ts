import { ParsedIniData } from "@aws-sdk/types";
export declare const parseIni: (iniData: string) => ParsedIniData;
