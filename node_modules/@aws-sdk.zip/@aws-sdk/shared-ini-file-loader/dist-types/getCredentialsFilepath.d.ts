export declare const ENV_CREDENTIALS_PATH = "AWS_SHARED_CREDENTIALS_FILE";
export declare const getCredentialsFilepath: () => string;
