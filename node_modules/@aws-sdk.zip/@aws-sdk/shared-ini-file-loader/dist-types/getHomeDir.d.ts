/**
 * Get the HOME directory for the current runtime.
 *
 * @internal
 */
export declare const getHomeDir: () => string;
