import { UserAgentPair } from "@aws-sdk/types";
/**
 * @internal
 */
export declare const isCrtAvailable: () => UserAgentPair | null;
