# @aws-sdk/util-hex-encoding

[![NPM version](https://img.shields.io/npm/v/@aws-sdk/util-hex-encoding/latest.svg)](https://www.npmjs.com/package/@aws-sdk/util-hex-encoding)
[![NPM downloads](https://img.shields.io/npm/dm/@aws-sdk/util-hex-encoding.svg)](https://www.npmjs.com/package/@aws-sdk/util-hex-encoding)
